#!/bin/bash
sudo apt update
sudo apt install gnome-tweak-tool
