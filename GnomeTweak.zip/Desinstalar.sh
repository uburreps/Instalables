#!/bin/bash
sudo apt remove gnome-tweak-tool
