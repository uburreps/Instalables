#!/bin/bash
sudo apt remove lollypop
