#!/bin/bash
sudo apt-add-repository ppa:gnumdk/lollypop
sudo apt update
sudo apt install lollypop
