#!/bin/bash
sudo apt-apt-repository ppa:gnumdk/lollypop
sudo apt update
sudo apt install lollypop
