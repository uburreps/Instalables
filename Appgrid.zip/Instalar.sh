#!/bin/bash

sudo add-apt-repository ppa:appgrid/stable
sudo apt update
sudo apt install appgrid
